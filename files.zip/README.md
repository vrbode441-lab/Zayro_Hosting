# 🖤 ALORD HOSTING
### Developed by 『 | 𝘼𝙡𝙤𝙧𝙙 𝙕𝙖𝙮𝙧𝙤 🖤 | 』

Cloud hosting platform for isolated Python scripts (bots, tools, etc.) running in Docker containers.

---

## 📁 Project Structure

```
alord-hosting/
├── app.py                  ← Flask backend (main application)
├── requirements.txt        ← Python dependencies
├── Dockerfile              ← Image for the Flask app
├── Dockerfile.sandbox      ← Isolated sandbox image for user scripts
├── docker-compose.yml      ← Full stack deployment
├── templates/
│   ├── auth.html           ← Login / Register page
│   ├── dashboard.html      ← Main control panel
│   └── server.html         ← Server detail + terminal + file manager
└── uploads/                ← User scripts (auto-created)
```

---

## 🚀 Quick Start

### Step 1 — Build the sandbox image
```bash
docker build -t alord-sandbox:latest -f Dockerfile.sandbox .
```

### Step 2 — Start the platform
```bash
docker-compose up -d
```

### Step 3 — Open in browser
```
http://localhost:5000
```

---

## ⚙️ Local Development (no Docker)

```bash
pip install -r requirements.txt
python app.py
```

> Without Docker running, the platform runs in **demo mode** (containers simulated).

---

## 🔒 Security Features

| Feature | Details |
|---|---|
| **Authentication** | PBKDF2-SHA256 password hashing (Werkzeug) |
| **Container isolation** | Each server = isolated Docker container |
| **CPU limit** | 0.5 cores per container |
| **RAM limit** | 256 MB per container |
| **Non-root** | Containers run as `sandbox:1000` user |
| **No new privileges** | `security_opt: no-new-privileges` |
| **Dropped capabilities** | `cap_drop: ALL` |
| **Max servers** | 7 per user |
| **File validation** | Only `.py .txt .json .env .yaml .cfg .ini` |

---

## 🧠 Auto-Installer

When you start a server, the platform automatically detects `requirements.txt` in your uploaded files and runs:

```bash
pip install -q -r requirements.txt && python -u main.py
```

---

## 📡 API Endpoints

| Method | Route | Description |
|---|---|---|
| `POST` | `/login` | Authenticate user |
| `POST` | `/register` | Create account |
| `GET` | `/dashboard` | Control panel |
| `POST` | `/server/create` | Create new server |
| `GET` | `/server/<id>` | Server detail page |
| `POST` | `/server/<id>/start` | Start container |
| `POST` | `/server/<id>/stop` | Stop container |
| `DELETE` | `/server/<id>/delete` | Delete server + files |
| `POST` | `/server/<id>/upload` | Upload file |
| `GET` | `/server/<id>/logs` | Get logs (JSON) |
| `GET` | `/server/<id>/logs/stream` | SSE real-time logs |
| `GET` | `/api/status/<id>` | Container status |

---

## 🌐 Environment Variables

| Variable | Default | Description |
|---|---|---|
| `SECRET_KEY` | `alord-secret...` | Flask session key |
| `DATABASE_URL` | `sqlite:///alord.db` | Database connection |

---

*Developed by 『 | 𝘼𝙡𝙤𝙧𝙙 𝙕𝙖𝙮𝙧𝙤 🖤 | 』*
