"""
╔══════════════════════════════════════════════════════════════╗
║          ALORD HOSTING - Cloud Platform                      ║
║          Developed by 『 | 𝘼𝙡𝙤𝙧𝙙 𝙕𝙖𝙮𝙧𝙤 🖤 | 』             ║
╚══════════════════════════════════════════════════════════════╝
"""

import os
import uuid
import json
import time
import shutil
import threading
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, render_template, request, redirect,
                   url_for, session, jsonify, Response, stream_with_context)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

try:
    import docker
    DOCKER_AVAILABLE = True
except ImportError:
    DOCKER_AVAILABLE = False
    print("[WARNING] Docker SDK not installed. Running in demo mode.")

# ─── App Configuration ────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "alord-secret-key-change-in-production-2024")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///alord.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB max upload
app.config["UPLOAD_FOLDER"] = os.path.join(os.path.dirname(__file__), "uploads")
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=7)

db = SQLAlchemy(app)

# ─── Constants ────────────────────────────────────────────────
MAX_SERVERS_PER_USER = 7
ALLOWED_EXTENSIONS = {"py", "txt", "json", "env", "cfg", "ini", "yaml", "yml"}
CONTAINER_CPU_LIMIT = 0.5       # 50% of 1 CPU core
CONTAINER_MEM_LIMIT = "256m"    # 256MB RAM
CONTAINER_MEM_SWAP = "512m"     # Swap limit

# Docker image for running user scripts
SANDBOX_IMAGE = "alord-sandbox:latest"

# In-memory log storage (container_id -> list of log lines)
container_logs: dict[str, list] = {}
log_lock = threading.Lock()

# ─── Database Models ──────────────────────────────────────────
class User(db.Model):
    __tablename__ = "users"
    id       = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email    = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)
    created  = db.Column(db.DateTime, default=datetime.utcnow)
    servers  = db.relationship("Server", backref="owner", lazy=True, cascade="all, delete-orphan")

class Server(db.Model):
    __tablename__ = "servers"
    id           = db.Column(db.Integer, primary_key=True)
    name         = db.Column(db.String(100), nullable=False)
    server_uuid  = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))
    user_id      = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    container_id = db.Column(db.String(64))           # Docker container short ID
    status       = db.Column(db.String(20), default="stopped")  # stopped | running | error
    main_file    = db.Column(db.String(256))           # e.g. main.py
    created      = db.Column(db.DateTime, default=datetime.utcnow)
    last_started = db.Column(db.DateTime)
    work_dir     = db.Column(db.String(512))           # host path for this server's files

# ─── Helpers ──────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def get_docker_client():
    if not DOCKER_AVAILABLE:
        return None
    try:
        client = docker.from_env()
        client.ping()
        return client
    except Exception as e:
        print(f"[Docker] Connection failed: {e}")
        return None

def get_server_work_dir(server_uuid: str, user_id: int) -> str:
    path = os.path.join(app.config["UPLOAD_FOLDER"], f"user_{user_id}", server_uuid)
    os.makedirs(path, exist_ok=True)
    return path

def append_log(server_uuid: str, line: str):
    with log_lock:
        if server_uuid not in container_logs:
            container_logs[server_uuid] = []
        ts = datetime.now().strftime("%H:%M:%S")
        container_logs[server_uuid].append(f"[{ts}] {line}")
        # Keep last 500 lines
        if len(container_logs[server_uuid]) > 500:
            container_logs[server_uuid] = container_logs[server_uuid][-500:]

def stream_container_logs(server: "Server"):
    """Background thread: stream Docker container logs into memory."""
    client = get_docker_client()
    if not client or not server.container_id:
        return
    try:
        container = client.containers.get(server.container_id)
        for log_line in container.logs(stream=True, follow=True):
            decoded = log_line.decode("utf-8", errors="replace").rstrip("\n")
            append_log(server.server_uuid, decoded)
    except Exception as e:
        append_log(server.server_uuid, f"[system] Log stream ended: {e}")

# ─── Auth Routes ──────────────────────────────────────────────
@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        data = request.get_json() or request.form
        username = str(data.get("username", "")).strip()
        email    = str(data.get("email", "")).strip().lower()
        password = str(data.get("password", ""))

        if not username or not email or not password:
            return jsonify({"ok": False, "msg": "All fields are required."}), 400
        if len(password) < 8:
            return jsonify({"ok": False, "msg": "Password must be at least 8 characters."}), 400
        if User.query.filter_by(username=username).first():
            return jsonify({"ok": False, "msg": "Username already taken."}), 409
        if User.query.filter_by(email=email).first():
            return jsonify({"ok": False, "msg": "Email already registered."}), 409

        hashed = generate_password_hash(password, method="pbkdf2:sha256:600000")
        user = User(username=username, email=email, password=hashed)
        db.session.add(user)
        db.session.commit()
        session.permanent = True
        session["user_id"] = user.id
        session["username"] = user.username
        return jsonify({"ok": True, "redirect": url_for("dashboard")}), 201

    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        data = request.get_json() or request.form
        username = str(data.get("username", "")).strip()
        password = str(data.get("password", ""))

        user = User.query.filter_by(username=username).first()
        if not user or not check_password_hash(user.password, password):
            return jsonify({"ok": False, "msg": "Invalid username or password."}), 401

        session.permanent = True
        session["user_id"] = user.id
        session["username"] = user.username
        return jsonify({"ok": True, "redirect": url_for("dashboard")}), 200

    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ─── Dashboard ────────────────────────────────────────────────
@app.route("/dashboard")
@login_required
def dashboard():
    user = db.session.get(User, session["user_id"])
    servers = Server.query.filter_by(user_id=user.id).order_by(Server.created.desc()).all()

    # Sync container status from Docker
    client = get_docker_client()
    if client:
        for srv in servers:
            if srv.container_id:
                try:
                    c = client.containers.get(srv.container_id)
                    srv.status = c.status  # running / exited / etc.
                except docker.errors.NotFound:
                    srv.status = "stopped"
                    srv.container_id = None
        db.session.commit()

    return render_template("dashboard.html", user=user, servers=servers,
                           max_servers=MAX_SERVERS_PER_USER)

# ─── Server Management ────────────────────────────────────────
@app.route("/server/create", methods=["POST"])
@login_required
def create_server():
    user_id = session["user_id"]
    count = Server.query.filter_by(user_id=user_id).count()
    if count >= MAX_SERVERS_PER_USER:
        return jsonify({"ok": False, "msg": f"Maximum {MAX_SERVERS_PER_USER} servers allowed."}), 403

    data = request.get_json() or request.form
    name = str(data.get("name", "")).strip() or f"Server-{count+1}"
    main_file = str(data.get("main_file", "main.py")).strip()

    srv = Server(name=name, user_id=user_id, main_file=main_file)
    db.session.add(srv)
    db.session.flush()  # get srv.id

    srv.work_dir = get_server_work_dir(srv.server_uuid, user_id)
    db.session.commit()
    return jsonify({"ok": True, "server_id": srv.id, "redirect": url_for("server_detail", server_id=srv.id)})

@app.route("/server/<int:server_id>")
@login_required
def server_detail(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()
    files = []
    if srv.work_dir and os.path.isdir(srv.work_dir):
        files = sorted(os.listdir(srv.work_dir))
    return render_template("server.html", server=srv, files=files)

@app.route("/server/<int:server_id>/upload", methods=["POST"])
@login_required
def upload_file(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()
    if "file" not in request.files:
        return jsonify({"ok": False, "msg": "No file provided."}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"ok": False, "msg": "Empty filename."}), 400
    if not allowed_file(file.filename):
        return jsonify({"ok": False, "msg": f"File type not allowed. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"}), 400

    filename = secure_filename(file.filename)
    work_dir = srv.work_dir or get_server_work_dir(srv.server_uuid, srv.user_id)
    srv.work_dir = work_dir
    db.session.commit()

    dest = os.path.join(work_dir, filename)
    file.save(dest)
    return jsonify({"ok": True, "filename": filename, "msg": f"'{filename}' uploaded successfully."})

@app.route("/server/<int:server_id>/start", methods=["POST"])
@login_required
def start_server(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()

    if srv.status == "running":
        return jsonify({"ok": False, "msg": "Server is already running."}), 400

    work_dir = srv.work_dir or get_server_work_dir(srv.server_uuid, srv.user_id)
    main_file = srv.main_file or "main.py"

    if not os.path.isfile(os.path.join(work_dir, main_file)):
        return jsonify({"ok": False, "msg": f"'{main_file}' not found. Please upload it first."}), 400

    client = get_docker_client()
    if not client:
        # Demo mode: simulate running
        srv.status = "running"
        srv.last_started = datetime.utcnow()
        db.session.commit()
        append_log(srv.server_uuid, "[demo] Docker not available — running in demo mode.")
        append_log(srv.server_uuid, f"[demo] Would execute: python {main_file}")
        return jsonify({"ok": True, "msg": "Server started (demo mode)."})

    # Stop old container if any
    if srv.container_id:
        try:
            old = client.containers.get(srv.container_id)
            old.remove(force=True)
        except Exception:
            pass

    # Build startup command: install deps then run script
    has_requirements = os.path.isfile(os.path.join(work_dir, "requirements.txt"))
    if has_requirements:
        cmd = f"pip install -q -r requirements.txt && python -u {main_file}"
    else:
        cmd = f"python -u {main_file}"

    append_log(srv.server_uuid, f"[system] Starting server '{srv.name}'...")
    if has_requirements:
        append_log(srv.server_uuid, "[system] requirements.txt detected — installing packages...")

    try:
        container = client.containers.run(
            image=SANDBOX_IMAGE,
            command=["sh", "-c", cmd],
            detach=True,
            remove=False,
            name=f"alord_{srv.server_uuid[:8]}",
            volumes={os.path.abspath(work_dir): {"bind": "/app", "mode": "rw"}},
            working_dir="/app",
            mem_limit=CONTAINER_MEM_LIMIT,
            memswap_limit=CONTAINER_MEM_SWAP,
            nano_cpus=int(CONTAINER_CPU_LIMIT * 1e9),
            network_mode="bridge",
            security_opt=["no-new-privileges:true"],
            cap_drop=["ALL"],
            read_only=False,
            environment={
                "PYTHONUNBUFFERED": "1",
                "PYTHONDONTWRITEBYTECODE": "1",
            },
            labels={"alord.user": str(srv.user_id), "alord.server": srv.server_uuid},
        )
        srv.container_id = container.short_id
        srv.status = "running"
        srv.last_started = datetime.utcnow()
        db.session.commit()

        # Stream logs in background
        t = threading.Thread(target=stream_container_logs, args=(srv,), daemon=True)
        t.start()

        return jsonify({"ok": True, "msg": f"Server '{srv.name}' started successfully!"})

    except docker.errors.ImageNotFound:
        srv.status = "error"
        db.session.commit()
        return jsonify({"ok": False, "msg": f"Docker image '{SANDBOX_IMAGE}' not found. Run: docker build -t {SANDBOX_IMAGE} ."}), 500
    except Exception as e:
        srv.status = "error"
        db.session.commit()
        append_log(srv.server_uuid, f"[error] {e}")
        return jsonify({"ok": False, "msg": str(e)}), 500

@app.route("/server/<int:server_id>/stop", methods=["POST"])
@login_required
def stop_server(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()

    client = get_docker_client()
    if client and srv.container_id:
        try:
            c = client.containers.get(srv.container_id)
            c.stop(timeout=5)
            c.remove()
        except Exception as e:
            append_log(srv.server_uuid, f"[system] Stop error: {e}")

    srv.status = "stopped"
    srv.container_id = None
    db.session.commit()
    append_log(srv.server_uuid, "[system] Server stopped.")
    return jsonify({"ok": True, "msg": f"Server '{srv.name}' stopped."})

@app.route("/server/<int:server_id>/delete", methods=["DELETE"])
@login_required
def delete_server(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()

    # Stop container
    client = get_docker_client()
    if client and srv.container_id:
        try:
            c = client.containers.get(srv.container_id)
            c.remove(force=True)
        except Exception:
            pass

    # Remove files
    if srv.work_dir and os.path.isdir(srv.work_dir):
        shutil.rmtree(srv.work_dir, ignore_errors=True)

    with log_lock:
        container_logs.pop(srv.server_uuid, None)

    db.session.delete(srv)
    db.session.commit()
    return jsonify({"ok": True, "msg": "Server deleted.", "redirect": url_for("dashboard")})

@app.route("/server/<int:server_id>/rename", methods=["POST"])
@login_required
def rename_server(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()
    data = request.get_json() or request.form
    new_name = str(data.get("name", "")).strip()
    if not new_name:
        return jsonify({"ok": False, "msg": "Name cannot be empty."}), 400
    srv.name = new_name
    db.session.commit()
    return jsonify({"ok": True, "msg": "Server renamed."})

# ─── Logs ─────────────────────────────────────────────────────
@app.route("/server/<int:server_id>/logs")
@login_required
def get_logs(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()
    with log_lock:
        logs = list(container_logs.get(srv.server_uuid, []))
    return jsonify({"ok": True, "logs": logs})

@app.route("/server/<int:server_id>/logs/stream")
@login_required
def stream_logs(server_id):
    """SSE endpoint for real-time log streaming."""
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()

    def generate():
        sent = 0
        while True:
            with log_lock:
                logs = container_logs.get(srv.server_uuid, [])
                new_lines = logs[sent:]
                sent = len(logs)
            for line in new_lines:
                yield f"data: {json.dumps(line)}\n\n"
            time.sleep(0.5)

    return Response(stream_with_context(generate()),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@app.route("/server/<int:server_id>/logs/clear", methods=["POST"])
@login_required
def clear_logs(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()
    with log_lock:
        container_logs[srv.server_uuid] = []
    return jsonify({"ok": True})

# ─── File Management ──────────────────────────────────────────
@app.route("/server/<int:server_id>/files")
@login_required
def list_files(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()
    files = []
    if srv.work_dir and os.path.isdir(srv.work_dir):
        for fname in sorted(os.listdir(srv.work_dir)):
            fpath = os.path.join(srv.work_dir, fname)
            if os.path.isfile(fpath):
                stat = os.stat(fpath)
                files.append({
                    "name": fname,
                    "size": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                })
    return jsonify({"ok": True, "files": files})

@app.route("/server/<int:server_id>/files/<filename>/delete", methods=["DELETE"])
@login_required
def delete_file(server_id, filename):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()
    safe = secure_filename(filename)
    fpath = os.path.join(srv.work_dir, safe)
    if os.path.isfile(fpath):
        os.remove(fpath)
        return jsonify({"ok": True, "msg": f"'{safe}' deleted."})
    return jsonify({"ok": False, "msg": "File not found."}), 404

@app.route("/server/<int:server_id>/files/<filename>/view")
@login_required
def view_file(server_id, filename):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()
    safe = secure_filename(filename)
    fpath = os.path.join(srv.work_dir, safe)
    if os.path.isfile(fpath):
        try:
            with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            return jsonify({"ok": True, "content": content})
        except Exception as e:
            return jsonify({"ok": False, "msg": str(e)}), 500
    return jsonify({"ok": False, "msg": "File not found."}), 404

# ─── API: Status Check ────────────────────────────────────────
@app.route("/api/status/<int:server_id>")
@login_required
def api_status(server_id):
    srv = Server.query.filter_by(id=server_id, user_id=session["user_id"]).first_or_404()
    client = get_docker_client()
    if client and srv.container_id:
        try:
            c = client.containers.get(srv.container_id)
            srv.status = c.status
            db.session.commit()
        except Exception:
            srv.status = "stopped"
            db.session.commit()
    return jsonify({"ok": True, "status": srv.status, "name": srv.name})

# ─── Entry Point ──────────────────────────────────────────────
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
        print("╔════════════════════════════════════════╗")
        print("║     ALORD HOSTING — Server Ready       ║")
        print("║  Developed by 『 | Alord Zayro 🖤 | 』  ║")
        print("╚════════════════════════════════════════╝")
    app.run(host="0.0.0.0", port=5000, debug=False)
